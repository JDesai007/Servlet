/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        RequestDispatcher dispatcher = null;
        HttpSession session = request.getSession();

        if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
            request.setAttribute("error", "Email and password are required.");
            dispatcher = request.getRequestDispatcher("index.jsp");
        } else {
            String roleName = authenticateUser(email, password);
            if (roleName != null) {
                session.setAttribute("email", email);
                session.setAttribute("roleName", roleName);

                if (roleName.equals("Admin")) {
                    dispatcher = request.getRequestDispatcher("adminhome.jsp");
                }
                if (roleName.equals("Guest")) {
                    dispatcher = request.getRequestDispatcher("guesthome.jsp");
                }
                if (roleName.equals("Registered User")) {
                    dispatcher = request.getRequestDispatcher("userhome.jsp");
                }

            } else {
                request.setAttribute("error", "Invalid email or password.");
                dispatcher = request.getRequestDispatcher("loginFail.jsp");
            }
        }

        dispatcher.forward(request, response);
    }

    private String authenticateUser(String email, String password) {
        String roleName = null;
        String query = "SELECT role.roleName FROM user JOIN role ON user.roleid = role.roleId WHERE email = ? AND password = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sem2", "root", "");
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                roleName = resultSet.getString("roleName");
            }
            connection.close();
        } catch (SQLException se) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, se);
        } catch (ClassNotFoundException e) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, e);
        }

        return roleName;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Login Servlet";
    }

}
