/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 91942
 */
public class CalculateCompoundInterest extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            /* TODO output your page here. You may use following sample code. */

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<meta charset=\"UTF-8\">");
            out.println("<title>Compound Interest Result</title>");
            out.println("<style>"
                    + "body {display: flex; justify-content: center;align-items: center; height: 100vh;margin: 0;font-family: Calibri, sans-serif; }"
                    + "input {width: 75%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}"
                    + "select { width: 75%; padding: 12px 20px;margin: 8px 0; display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}"
                    + "label {color: black;font-size:18px; width:150px; text-align: left; font-family: Calibri, sans-serif;}"
                    + "button {width: 30%; background-color: #607d8b;color: white; padding: 14px 20px; margin: 8px 15px; border: none; border-radius: 4px;cursor: pointer;}"
                    + "button:hover {background-color: #78909c;}"
                    + "div.container { border-radius: 5px; background-color: #f2f2f2; padding: 30px;}"
                    + "th, td { padding: 10px; text-align: left;}"
                    + "th { width:50px;  background-color: #607d8b; color: white;}"
                    + ".currency { background-color: #607d8b;color: white; padding: 10px; border-radius: 4px; }"
                    + "</style>");
            out.println("</head>");
            out.println("<body>");
            double amount = Double.parseDouble(request.getParameter("amount"));
            double rate = Double.parseDouble(request.getParameter("rate"));
            double year = Double.parseDouble(request.getParameter("year"));
            double months = Double.parseDouble(request.getParameter("months"));
            String calculateinterest = request.getParameter("calculateinterest");
 
            ArrayList<String> errors = new ArrayList<String>();
            
            if (amount <= 0) {
                errors.add("Principal amount must be greater than zero.");
            }

            if (rate <= 0 || rate >=100) {
                errors.add("Interest rate must be greater than zero.");
            }

            if (year < 0) {
                errors.add("Year must be greater than zero.");
            }

            if (months < 0 || months >=11) {
                errors.add("Month must be greater than zero.");
            }
            
            if (months == 0 || year == 0) {
                errors.add("Month and Year must be required.");
            }

            if (calculateinterest == null) {
                errors.add("Compound Interval must be selected.");
            }

            if (!errors.isEmpty()) {
                request.setAttribute("errors", errors);
                RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
                dispatcher.forward(request, response);
                return;
            }

            double time = (year * 12 + months) / 12;
            double interest = 0.0;

            if (calculateinterest.equals("daily")) {
                interest = amount * Math.pow((1 + rate / (365 * 100)), 365 * time);
            } else if (calculateinterest.equals("daily360")) {
                interest = amount * Math.pow((1 + rate / (360 * 100)), 360 * time);
            } else if (calculateinterest.equals("semiweekly")) {
                interest = amount * Math.pow((1 + rate / (104 * 100)), 104 * time);
            } else if (calculateinterest.equals("weekly")) {
                interest = amount * Math.pow((1 + rate / (52 * 100)), 52 * time);
            } else if (calculateinterest.equals("biweekly")) {
                interest = amount * Math.pow((1 + rate / (26 * 100)), 26 * time);
            } else if (calculateinterest.equals("semimonthly")) {
                interest = amount * Math.pow((1 + rate / (24 * 100)), 24 * time);
            } else if (calculateinterest.equals("monthly")) {
                interest = amount * Math.pow((1 + rate / (12 * 100)), 12 * time);
            } else if (calculateinterest.equals("bimonthly")) {
                interest = amount * Math.pow((1 + rate / (6 * 100)), 6 * time);
            } else if (calculateinterest.equals("quarterly")) {
                interest = amount * Math.pow((1 + rate / (4 * 100)), 4 * time);
            } else if (calculateinterest.equals("halfyearly")) {
                interest = amount * Math.pow((1 + rate / (2 * 100)), 2 * time);
            } else if (calculateinterest.equals("yearly")) {
                interest = amount * Math.pow((1 + rate), time);
            }

            String interestFormate = String.format("%.2f", interest);

            out.println("<table >");
            out.println("<thead>");
            out.println("<tr>");
            out.println("<th colspan=\"2\"><center><h2>Compound Interest Result</h2></center></th>");
            out.println("</tr>");
            out.println("</thead>");
            out.println("<tbody>");
            out.println("<form>");
            out.println("<tr>");
            out.println("<td><label for=\"amount\">Principal Amount:</label></td>");
            out.println("<td><span class=\"currency\">₹</span><input type=\"text\" id=\"amount\" name=\"amount\" value=" + amount + " readonly></td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td><label for=\"rate\">Interest Rate:</label></td>");
            out.println("<td><input type=\"text\" id=\"rate\" name=\"rate\" value=" + rate + " readonly><span class=\"currency\">%</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");

            out.println("</tr>");
            out.println("<tr>");
            out.println("<td><label for=\"year\">Years:</label></td>");
            out.println("<td><input type=\"text\" id=\"year\" name=\"year\" value=" + year + " readonly></td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td><label for=\"months\">Months:</label></td>");
            out.println("<td><input type=\"text\" id=\"months\" name=\"months\" value=" + months + " readonly></td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td><label for=\"calculateinterest\">Compound Interval:</label></td>");
            out.println("<td><select name=\"calculateinterest\" id=\"calculateinterest\" disabled>");
            out.println("<option value=\"\">" + calculateinterest + "</option>");

            out.println("</select></td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<th colspan=\"2\"><center><h2>The calculated amount is: " + interestFormate + "</h2></center></th>");
            out.println("</tr>");
            out.println("</form>");
            out.println("</tbody>");
            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
