/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 91942
 */
public class Display extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<style>");
        out.println("table {border-spacing: 10px;  width: 100%;}");
        out.println("th, td {padding: 10px;  text-align: left;  background-color: #f2f2f2;}");
        out.println("th {font-weight: bold;  background-color: #ddd;}");
        out.println("</style>");

        out.println("<br><table>");
        out.println("<tr><th colspan='2'>Request Details</th></tr>");
        out.println("<tr><td>HTTP Method:</td><td>" + request.getMethod() + "</td></tr>");
        out.println("<tr><td>Request URI:</td><td>" + request.getRequestURI() + "</td></tr>");
        out.println("<tr><td>Protocol:</td><td>" + request.getProtocol() + "</td></tr>");
        
       
        out.println("<tr><th colspan='2'>Header Details</th></tr>");
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            String headerValue = request.getHeader(headerName);
            out.println("<tr><td>" + headerName + "</td><td>" + headerValue + "</td></tr>");
        }

       
       
        out.println("<tr><th colspan='2'>Client/Browser Details</th></tr>");
        out.println("<tr><td>User Agent:</td><td>" + request.getHeader("User-Agent") + "</td></tr>");
        out.println("<tr><td>Accept:</td><td>" + request.getHeader("Accept") + "</td></tr>");
        out.println("<tr><td>Accept-Language:</td><td>" + request.getHeader("Accept-Language") + "</td></tr>");
        out.println("<tr><td>Accept-Encoding:</td><td>" + request.getHeader("Accept-Encoding") + "</td></tr>");
        out.println("<tr><td>Connection:</td><td>" + request.getHeader("Connection") + "</td></tr>");
        
        out.println("<tr><th colspan='2'>Client Details</th></tr>");
        out.println("<tr><td>Remote Address:</td><td>" + request.getRemoteAddr() + "</td></tr>");
        out.println("<tr><td>Remote Host:</td><td>" + request.getRemoteHost() + "</td></tr>");
        out.println("<tr><td>Remote Port:</td><td>" + request.getRemotePort() + "</td></tr>");

        out.println("<tr><th colspan='2'>Browser Details</th></tr>");
        out.println("<tr><td>Local Address:</td><td>" + request.getLocalAddr() + "</td></tr>");
        out.println("<tr><td>Local Name:</td><td>" + request.getLocalName() + "</td></tr>");
        out.println("<tr><td>Local Port:</td><td>" + request.getLocalPort() + "</td></tr>");
        
       
        out.println("<tr><th colspan='2'>Server Details</th></tr>");
        out.println("<tr><td>Server Name:</td><td>" + request.getServerName() + "</td></tr>");
        out.println("<tr><td>Server Port:</td><td>" + request.getServerPort() + "</td></tr>");
        out.println("<tr><td>Servlet Name:</td><td>" + getServletConfig().getServletName() + "</td></tr>");
        out.println("</table>");

        out.close();
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
